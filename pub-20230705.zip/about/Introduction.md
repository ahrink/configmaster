A Dialog to? – experiment

Composition:
   1. Installer is also the initializer: DemoINI.sh
   2. app_start.sh is a validator to start Dialog
   3. [work space is defined Demo] a Dialog experiment
   4. All other components are in LastWord.md
   5. This code was tested and working on fresh Ubuntu 22.04

Process: [all confined to a folder]

Once the app is initialized is expecting the user to enjoy a variety of shell sh programing mostly focused on Dialog usage. However, the working-code includes examples that many coders have a hard time understanding. As a result, a secondary thought is implied eg didactic.

Have fun,

San Anton [via terminal ssh]
PS: All open code, and spare my intellect from wasting time with writing disclaimers, infringements etc.
Fact is, it is provided as is with no liability attach other than didactic.

More when it comes as it comes:
© San Anton™ [t] AHR: in pretio procedere doctrina speramus
        https://www.zerohedge.com/user/339741

Note: The archive includes only text files:
app_start.sh
ChineseQ.ahr
DemoINI.sh
funcLib.sh
mm_app.sh
about # subfolder
LastWord.md
Introduction.md # this file

How2 also read LastWord.md:
Place these files into a folder and run "sh DemoINI.sh":
app_start.sh
ChineseQ.ahr
DemoINI.sh
funcLib.sh
mm_app.sh

REM: it is working but do not try w/o install/initialization and validation process exposed above.
